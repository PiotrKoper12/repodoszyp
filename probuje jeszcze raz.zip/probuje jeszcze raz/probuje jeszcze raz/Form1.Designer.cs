﻿namespace probuje_jeszcze_raz
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            button1 = new Button();
            numericUpDown1 = new NumericUpDown();
            button2 = new Button();
            numericUpDown2 = new NumericUpDown();
            button3 = new Button();
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            label6 = new Label();
            label7 = new Label();
            checkBox3 = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20F);
            label1.Location = new Point(237, 9);
            label1.Name = "label1";
            label1.Size = new Size(318, 46);
            label1.TabIndex = 0;
            label1.Text = "Apka do sortowania";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F);
            label2.Location = new Point(30, 88);
            label2.Name = "label2";
            label2.Size = new Size(225, 64);
            label2.TabIndex = 1;
            label2.Text = "tu wprowadz liczbe \r\ndo tablicy liczb\r\n";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15F);
            label3.Location = new Point(288, 264);
            label3.Name = "label3";
            label3.Size = new Size(149, 35);
            label3.TabIndex = 3;
            label3.Text = "twoje liczby:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F);
            label4.Location = new Point(330, 315);
            label4.Name = "label4";
            label4.Size = new Size(0, 20);
            label4.TabIndex = 4;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 13F);
            label5.Location = new Point(479, 76);
            label5.Name = "label5";
            label5.Size = new Size(204, 60);
            label5.TabIndex = 5;
            label5.Text = "wprowadz tu pierw \r\nwielkosc tablicy";
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 15F);
            button1.Location = new Point(561, 155);
            button1.Name = "button1";
            button1.Size = new Size(147, 66);
            button1.TabIndex = 7;
            button1.Text = "Generuj";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Font = new Font("Segoe UI", 40F);
            numericUpDown1.Location = new Point(479, 136);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(76, 96);
            numericUpDown1.TabIndex = 8;
            numericUpDown1.ValueChanged += numericUpDown1_ValueChanged;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 15F);
            button2.Location = new Point(139, 173);
            button2.Name = "button2";
            button2.Size = new Size(149, 53);
            button2.TabIndex = 9;
            button2.Text = "Wprowadz";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // numericUpDown2
            // 
            numericUpDown2.Font = new Font("Segoe UI", 40F);
            numericUpDown2.Location = new Point(30, 155);
            numericUpDown2.Name = "numericUpDown2";
            numericUpDown2.Size = new Size(91, 96);
            numericUpDown2.TabIndex = 10;
            numericUpDown2.ValueChanged += numericUpDown2_ValueChanged;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 15F);
            button3.Location = new Point(311, 441);
            button3.Name = "button3";
            button3.Size = new Size(116, 46);
            button3.TabIndex = 11;
            button3.Text = "Sortuj";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(181, 402);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(118, 24);
            checkBox1.TabIndex = 12;
            checkBox1.Text = "CountingSort";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(311, 402);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(95, 24);
            checkBox2.TabIndex = 13;
            checkBox2.Text = "QuickSort";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(311, 376);
            label6.Name = "label6";
            label6.Size = new Size(105, 20);
            label6.TabIndex = 14;
            label6.Text = "Wybierz jedno";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(253, 502);
            label7.Name = "label7";
            label7.Size = new Size(234, 20);
            label7.TabIndex = 15;
            label7.Text = "tu pojawia sie posortowane liczby";
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(428, 402);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(105, 24);
            checkBox3.TabIndex = 16;
            checkBox3.Text = "BubbleSort";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(724, 533);
            Controls.Add(checkBox3);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(checkBox2);
            Controls.Add(checkBox1);
            Controls.Add(button3);
            Controls.Add(numericUpDown2);
            Controls.Add(button2);
            Controls.Add(numericUpDown1);
            Controls.Add(button1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Aplikacja do sortowania (Kopsort)";
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button button1;
        private NumericUpDown numericUpDown1;
        private Button button2;
        private NumericUpDown numericUpDown2;
        private Button button3;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private Label label6;
        private Label label7;
        private CheckBox checkBox3;
    }
}
