namespace probuje_jeszcze_raz
{
    public partial class Form1 : Form
    {
        int i = 0;
        int liczbazmieniona = 0;
        int[] tab;
        public Form1()
        {
            InitializeComponent();
        }


        static void BubbleSort(int[] array)
        {
            int n = array.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    if (array[j] > array[j + 1])
                    {
                        Swap(array, j, j + 1);
                    }
                }
            }
        }
        static void CountingSort(int[] array)
        {

            int maxValue = FindMaxValue(array);
            int[] countArray = new int[maxValue + 1];
            for (int i = 0; i < array.Length; i++)
            {
                countArray[array[i]]++;
            }

            int sortedIndex = 0;
            for (int i = 0; i < countArray.Length; i++)
            {
                while (countArray[i] > 0)
                {
                    array[sortedIndex] = i;
                    sortedIndex++;
                    countArray[i]--;
                }
            }
        }

        static int FindMaxValue(int[] array)
        {
            int maxValue = array[0];
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] > maxValue)
                {
                    maxValue = array[i];
                }
            }
            return maxValue;
        }

        static void QuickSort(int[] array, int low, int high)
        {
            if (low < high)
            {
                int pivotIndex = Partition(array, low, high);
                QuickSort(array, low, pivotIndex - 1);
                QuickSort(array, pivotIndex + 1, high);
            }
        }

        static int Partition(int[] array, int low, int high)
        {
            int pivot = array[high];
            int i = low - 1;

            for (int j = low; j < high; j++)
            {
                if (array[j] <= pivot)
                {
                    i++;
                    Swap(array, i, j);
                }
            }
            Swap(array, i + 1, high);
            return i + 1;
        }

        static void Swap(int[] array, int i, int j)
        {
            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            tab = new int[(int)numericUpDown1.Value];
            MessageBox.Show("Wygenerowano tablice");
            string tekst;
            tab[i] = liczbazmieniona;
            tekst = string.Join(" ", tab);
            tekst = tekst.Replace("0", "");
            label4.Text = tekst;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }


        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            liczbazmieniona = (int)numericUpDown2.Value;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (i == tab.Length)
            {
                MessageBox.Show("Ale co pan tu sprawdza, toc nie idzie tak dodac kolejnej");
            }
            else
            {
                string tekst;
                tab[i] = liczbazmieniona;
                tekst = string.Join(" ", tab);
                tekst = tekst.Replace("0", "");
                label4.Text = tekst;
                i++;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(checkBox1.Checked ==true && checkBox2.Checked==true&&checkBox3.Checked==true|| checkBox1.Checked == true && checkBox2.Checked == true|| checkBox2.Checked == true && checkBox3.Checked == true|| checkBox1.Checked == true && checkBox3.Checked == true)
            {
                MessageBox.Show("to ze ktos nie zamkn�� narodowego to jest nic w por�wnaniu do tego co ty pr�bujesz zrobic");
            }
            if(checkBox1.Checked==true)
            {
                CountingSort(tab);
                label7.Text = String.Join(" ",tab);
            }
            if(checkBox2.Checked==true)
            {
                QuickSort(tab, 0, tab.Length - 1);
                label7.Text = String.Join(" ", tab);
            }
            if (checkBox3.Checked == true)
            {
                BubbleSort(tab);
                label7.Text = String.Join(" ", tab);
            }
            if (checkBox1.Checked==false&&checkBox2.Checked==false&&checkBox3.Checked==false)
            {
                MessageBox.Show("czem�");
            }
        }
    }
}
